.. _changelog:

Changelog
=========

`15.0.1.0.0`
------------

- Migration from 14.0


