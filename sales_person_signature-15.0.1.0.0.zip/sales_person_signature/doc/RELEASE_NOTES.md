## Module <sales_person_signature>

#### 06.01.2020
#### Version 15.0.1.0.0
##### ADD
- Initial commit
